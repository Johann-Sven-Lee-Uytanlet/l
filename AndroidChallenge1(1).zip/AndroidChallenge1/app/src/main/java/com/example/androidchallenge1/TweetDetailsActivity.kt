package com.example.androidchallenge1

import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class TweetDetailsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.tweetdetailsactivity)

        // Retrieve data from the Intent
        val userHandle = intent.getStringExtra("userHandle") ?: ""
        val displayName = intent.getStringExtra("displayName") ?: ""
        val caption = intent.getStringExtra("caption") ?: ""
        val likes = intent.getIntExtra("likes", 0)
        val imageId = intent.getIntExtra("imageId", 0)
        val createdAt = intent.getStringExtra("createdAt") ?: ""


        // Find the views in the layout
        val userHandleView: TextView = findViewById(R.id.user_handle)
        val displayNameView: TextView = findViewById(R.id.display_name)
        val captionView: TextView = findViewById(R.id.caption)
        val likesView: TextView = findViewById(R.id.likes)
        val tweetImageView: ImageView = findViewById(R.id.tweet_image)
        val dateView: TextView = findViewById(R.id.date)

        // Set the data to the views
        userHandleView.text = "@$userHandle"
        displayNameView.text = displayName
        captionView.text = caption
        likesView.text = "$likes likes"
        tweetImageView.setImageResource(imageId)
        dateView.text = createdAt
    }
}
