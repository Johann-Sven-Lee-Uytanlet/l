package com.example.androidchallenge1

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity

class AddTweetActivity : AppCompatActivity() {
    private lateinit var cancelBtn: Button
    private lateinit var tweetBtn: Button
    private lateinit var tweetEt: EditText
    private lateinit var userImageIv: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.addtweetactivity)

        cancelBtn = findViewById(R.id.cancelBtn)
        tweetBtn = findViewById(R.id.tweetBtn)
        tweetEt = findViewById(R.id.tweetEt)
        userImageIv = findViewById(R.id.userImageIv)

        userImageIv.setImageResource(R.drawable.lotad)

        cancelBtn.setOnClickListener {
            finish()
        }

        tweetBtn.setOnClickListener { view ->

            val tweetText = tweetEt.text.toString()

        }
    }
}
