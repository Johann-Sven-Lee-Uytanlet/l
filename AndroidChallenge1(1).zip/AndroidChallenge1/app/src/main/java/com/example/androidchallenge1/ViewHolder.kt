package com.example.androidchallenge1

import android.content.Intent
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
    private val userHandle: TextView = itemView.findViewById(R.id.user_handle)
    private val displayName: TextView = itemView.findViewById(R.id.display_name)
    private val caption: TextView = itemView.findViewById(R.id.caption)
    private val likes: TextView = itemView.findViewById(R.id.likes)
    private val tweetImage: ImageView = itemView.findViewById(R.id.tweet_image)
    private val date: TextView = itemView.findViewById(R.id.date)
    private var currentTweet: Tweet? = null

    init {
        // Set the OnClickListener for the itemView
        itemView.setOnClickListener {
            currentTweet?.let { tweet ->
                // Create an intent to start TweetDetailsActivity
                val context = itemView.context
                val intent = Intent(context, TweetDetailsActivity::class.java).apply {
                    // Pass the tweet data to the new activity
                    putExtra("userHandle", tweet.userHandle)
                    putExtra("displayName", tweet.displayName)
                    putExtra("caption", tweet.caption)
                    putExtra("likes", tweet.likes)
                    putExtra("imageId", tweet.imageId)
                    putExtra("createdAt", tweet.createdAt.toStringFull()) // Pass the date as long
                }
                context.startActivity(intent) // Start the activity
            }
        }
    }

    fun bind(tweet: Tweet) {
        currentTweet = tweet

        displayName.text = tweet.displayName
        userHandle.text = "@" + tweet.userHandle
        caption.text = tweet.caption
        likes.text = "${tweet.likes} likes"
        tweetImage.setImageResource(tweet.imageId)
        date.text = tweet.createdAt.toStringNoYear()
    }
}
