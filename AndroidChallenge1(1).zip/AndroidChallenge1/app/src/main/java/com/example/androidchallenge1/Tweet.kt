package com.example.androidchallenge1

class Tweet { 
    var userHandle: String
        private set
    var displayName: String
        private set
    var caption: String
        private set
    var likes: Int
        private set
    var imageId: Int
        private set
    var createdAt: CustomDate
        private set

    // Creates a Tweet providing all information. This used in the DataHelper class.
    constructor(userHandle: String, displayName: String, caption: String, likes: Int, imageId: Int, createdAt: CustomDate) {
        this.userHandle = userHandle
        this.displayName = displayName
        this.caption = caption
        this.likes = likes
        this.imageId = imageId
        this.createdAt = createdAt
    }

    // Creates a tweet with limited information. Here, the likes, image, and date are
    // initialized. This is meant for when the user creates a tweet. You can even modify
    // this constructor to accept only a caption and have the userHandle and displayName
    // initialized inside since they won't change for our problem.
    constructor(userHandle: String, displayName: String, caption: String) {
        this.userHandle = userHandle
        this.displayName = displayName
        this.caption = caption
        likes = 0

        // Please make sure to supply your own image.
        imageId = R.drawable.lotad
        
        // This creates a CustomDate object using the current date.
        createdAt = CustomDate()
    }
}