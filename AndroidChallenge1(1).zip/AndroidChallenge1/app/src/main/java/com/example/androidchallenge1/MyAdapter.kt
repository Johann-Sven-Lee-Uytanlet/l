package com.example.androidchallenge1

import android.view.ViewGroup
import android.view.LayoutInflater
import androidx.recyclerview.widget.RecyclerView

class MyAdapter(private val data: ArrayList<Tweet>) : RecyclerView.Adapter<ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        // Inflate your item layout and create the ViewHolder
        val view = LayoutInflater.from(parent.context).inflate(R.layout.itemrow, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        // Bind the Tweet data to the ViewHolder
        val tweet = data[position]
        holder.bind(tweet)
    }

    override fun getItemCount(): Int {
        return data.size
    }
}
