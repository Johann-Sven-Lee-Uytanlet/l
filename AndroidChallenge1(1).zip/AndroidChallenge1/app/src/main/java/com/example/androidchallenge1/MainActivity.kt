package com.example.androidchallenge1

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.recyclerview.widget.RecyclerView
import com.example.androidchallenge1.ui.theme.AndroidChallenge1Theme
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager


class MainActivity : AppCompatActivity() {
    private val tweetlist: ArrayList<Tweet> = DataHelper.loadTweetData()
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: MyAdapter
    private lateinit var button3: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.main_layout)
        button3 = findViewById(R.id.button3)

        recyclerView = findViewById(R.id.recyclerView)
        adapter = MyAdapter(tweetlist)

        recyclerView.adapter = adapter
        recyclerView.layoutManager = LinearLayoutManager(this)
        //Log.d("MainActivity", "Tweetlist size: ${tweetlist.size}")


        button3.setOnClickListener {
            val intent = Intent(this, AddTweetActivity::class.java)
            startActivity(intent)
        }
    }
}

